import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='geonui',
    application_name='aws-serverless-diet-app',
    app_uid='Lb5cVS9jvZS2xrP3qP',
    org_uid='6e8f2dda-87c4-4202-8394-5b9f6aa9e67a',
    deployment_uid='603fff55-3234-4f7f-9478-5a742fa073c6',
    service_name='aws-serverless-diet-app',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='6.2.3',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'aws-serverless-diet-app-dev-api', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('wsgi_handler.handler')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
